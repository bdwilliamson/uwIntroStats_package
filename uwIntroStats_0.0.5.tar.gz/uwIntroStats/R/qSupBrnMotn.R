qSupBrnMotn <-
function (conf) ifelse(conf==.95,2.2414,NA)
