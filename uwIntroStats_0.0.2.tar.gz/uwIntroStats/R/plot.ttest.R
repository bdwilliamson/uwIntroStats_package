plot.ttest <-
function(x,...) {
    
}
