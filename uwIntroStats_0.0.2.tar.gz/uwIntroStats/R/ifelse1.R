ifelse1 <-
function (test, x, y) if (test) x else y
