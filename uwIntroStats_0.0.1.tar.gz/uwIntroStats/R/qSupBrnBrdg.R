qSupBrnBrdg <-
function (conf) ifelse(conf==.95,1.3581,NA)
